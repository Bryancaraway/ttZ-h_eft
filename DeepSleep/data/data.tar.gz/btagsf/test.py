from ROOT import TFile, TTree, TObject, std
import re
import sys
if __name__ == '__main__':
    import subprocess as sb
    sys.path.insert(1, sb.check_output('echo $(git rev-parse --show-cdup)', shell=True).decode().strip('\n')+'DeepSleep/')
from array import array
import numpy as np
import config.ana_cff as cfg
from lib.fun_library import t2Run


old = TFile("test.root","UPDATE")

t = old.Get("Events")

#test_var = array("i",[0])
#new_branch = t.Branch('test',test_var,'test_var[nJet]/I')

v = std.vector('double')()
new_branch = t.Branch('testv',v)


for i in range(t.GetEntries()):    
    
    #test_var[0] = i
    #test_var[1] = i*10
    #test_var[2] = 0
    v.clear()
    if i % 1000 == 0:
        print(i)
    n_j = np.random.randint(1,10) 
    for j in range(n_j):
        v.push_back(float(j))
    if i % 1000 == 0:
        print(v)
    new_branch.Fill()
    #t.Fill()
    #v.clear()

#t.ResetBranchAddresses()
t.Write("", TObject.kOverwrite)


class BtagCalib : 
    
    '''
    BtagCalib class should take in input root file
    and update existing trees with additional
    btag shape sf jes uncertaintes 
    corresponding to the reduced set of jes sources

    these are taken from BTV csv files
    which we must interpret
    '''
    #
    '''
    DeepCSV_2016LegacySF_V1.csv  DeepCSV_2016LegacySF_V1_TuneCP5.csv  DeepCSV_94XSF_V5_B_F.csv
    '''
    csv_dict = {
        '2016': 'DeepCSV_2016LegacySF_V1_TuneCP5.csv',
        '2017': 'DeepCSV_94XSF_V5_B_F.csv',
        '2018': 'DeepCSV_102XSF_V2.csv',
    }

    def __init__(self, roo, year):
        self.roo  = TFile(roo, "UPDATE")
        self.tree = self.roo.Get("Events")
        self.btag_csv = open(self.csv_dict[year]).readlines()
        self.interp_btag_csv()
        #
        self.n_entries = self.tree.GetEntries()
        
    @t2Run
    def run(self,):
        self.write()

    def read(self):
        pass

    def write(self):
        v = std.vector('double')()
        new_branch = self.tree.Branch('testv',v)
        for i in range(self.n_entries):    
            v.clear()
            if i % 1000 == 0:
                print(i)
            n_j = np.random.randint(1,10) 
            for j in range(n_j):
                v.push_back(float(j))
            if i % 1000 == 0:
                print(v)
            new_branch.Fill()
        #
        self.tree.Write("", TObject.kOverwrite)

    def close(self):
        self.tree.Close()

    def interp_btag_csv(self):
        # first get jes list
        full_jes_list = cfg.jecs
        for l in self.btag_csv:
            pass

class OutBranch :
    '''
    define new branches
    and linked vectors here
    '''
    b_preffix = 'Jet_btagSF_deepcsv_shape_'
    
    def __init__(self, tree, jes_set):
        self.tree
        self.jes_set = jes_set # get jes names based on year
        # name must have format :
        # Jet_btagSF_deepcsv_shape_[up/down]_[sys]
        self.bv_dict = {ud+k : std.vector('double')() for k in self.jes_set for ud in ['up_','down_']}
        self.bv_dict.update({'b_'+k : self.tree.Branch(self.b_preffix+k,self.bc_dict[k]) for k in self.bv_dict})

    def __getitem__(self, _key):
        return self.bv_dict[_key]

    def clear(self):
        for k in self.bv_dict:
            if k[:2] != 'b_':
                self.bv_dict[k].clear()
    def Fill(self):
        for k in self.bv_dict:
            if k[:2] == 'b_':
                self.bv_dict[k].Fill()


def main():
    btagsf = BtagCalib(roo)
    btagsf.run()

if __name__ == '__main__':
    main()
