## short script to edit jec and jer files to
## satify the format of coffea jetmet
## file evaluator

from glob import glob
import subprocess as sb
import os
# go to the right directory
if __name__ == '__main__':

    os.system('cd '+sb.check_output('echo $(git rev-parse --show-cdup)', shell=True).decode().strip('\n')+'DeepSleep/data')

def editFileNames(jec_type):
    jme_files = glob(f'./{jec_type}/*/*.txt')
    replace_text = (lambda x,y: x.replace('.txt', f'.{y}.txt') if f'{y}.txt' not in x else x)
    for jme in jme_files:
        if jec_type == 'jec':
            if 'Uncertainty' not in jme:
                new_jme = replace_text(jme, 'jec')
                if jme != new_jme:
                    os.system(f'mv {jme} {new_jme}')
            else:
                new_jme = replace_text(jme, 'junc')
                if jme != new_jme:
                    os.system(f'mv {jme} {new_jme}')
        elif jec_type == 'jer':
            if 'SF' not in jme:
                new_jme = replace_text(jme, 'jr')
                if jme != new_jme:
                    os.system(f'mv {jme} {new_jme}')
            else:
                new_jme = replace_text(jme, 'jersf')
                if jme != new_jme:
                    os.system(f'mv {jme} {new_jme}')


editFileNames('jec')
editFileNames('jer')
