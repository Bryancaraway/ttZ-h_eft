# define the correct normalization and rate unc for tt_bb
import os
import sys
if __name__ == '__main__':
    import subprocess as sb
    sys.path.insert(1, sb.check_output('echo $(git rev-parse --show-cdup)', shell=True).decode().strip('\n')+'DeepSleep/')
from modules.AnaDict import AnaDict
#import pandas as pd
import numpy as np
# 

tt_bb_csv = open('/home/bcaraway/ttZh_ana/DeepSleep/data/tt_bb.csv')
csv_lines = np.array([i for i in tt_bb_csv.readlines()])
csv = np.array([np.array(line.split(',')) for line in csv_lines])
tt_bb_csv.close()
# lookup maps to csv
index         = {line.split(',')[0].replace('Powheg','powheg').replace('TToSemiLeptonic_UEUp_2017', 'TTToSemiLeptonic_UEUp_2017'): i # because of a copy-paste error 
                for i, line in enumerate(csv_lines) 
                if line.split(',')[0] is not None and line.split(',')[0] is not ''}
tot_col_dict  =  { s.strip('.').replace(' ', '_'):i+1 
                  for i, s in enumerate(csv_lines[2].strip('\n').strip().split(',')[1:13]) 
                  if s is not None and s is not ''}
ttbb_col_dict = {'ttbb_'+s.strip('.').replace(' ', '_'):i+13 
                 for i, s in enumerate(csv_lines[2].strip('\n').strip().split(',')[13:]) 
                 if s is not None and s is not ''}
col_dict = {**tot_col_dict,**ttbb_col_dict}
#
ded_col_dict =  { s.strip('.').replace(' ', '_'):i for i, s in enumerate(csv_lines[24].strip('\n').strip().split(',')) if s is not None and s is not ''}
#{'xsec': 1, 'Tot_Yield': 2, 'mu_r_up': 3, 'mu_r_down': 4, 'mu_f_up': 5, 'mu_f_down': 6, 'mu_rf_up': 7, 'mu_rf_down': 8, 'isr_up': 9, 'isr_down': 10, 'fsr_up': 11, 'fsr_down': 12}
#{'ttbb_Tot_Yield': 13, 'ttbb_mu_r_up': 14, 'ttbb_mu_r_down': 15, 'ttbb_mu_f_up': 16, 'ttbb_mu_f_down': 17, 'ttbb_mu_rf_up': 18, 'ttbb_mu_rf_down': 19, 'ttbb_isr_up': 20, 'ttbb_isr_down': 21, 'ttbb_fsr_up': 22, 'ttbb_fsr_down': 23}
#{'Sample_': 0, 'xsec': 1, 'Tot_Yield': 2, 'tt_bb_yield': 3}
lumi = {
    '2016':35917.149,
    '2017':41525.338,
    '2018':59724.44
}

ttxsec = {
    'Had'  :380.095,
    'Semi' :364.018,
    'Di'   :88.29
}
processes = {'SemiLeptonic':'Semi',
             '2L2Nu':'Di',
             'Hadronic':'Had'}


tt_bb_dict = AnaDict({'weight':{}, 'scale':{}})

get_weight =  (lambda new, old, events, p, y : (float(old)/float(new))*ttxsec[p]/float(events) * lumi[y])
get_scale  = (lambda nom_frac, var_frac: 1+ ( nom_frac - var_frac )/ nom_frac )

# first nominal weights
for year in lumi:
    for p,tt in processes.items():
        for key, sys in {'Tot_Yield':'nom', 'mu_r_up':'mu_r_Up', 'mu_r_down':'mu_r_Down', 'mu_f_up':'mu_f_Up', 
                         'mu_f_down':'mu_f_Down', 'mu_rf_up':'mu_rf_Up', 'mu_rf_down':'mu_rf_Down', 'isr_up':'ISR_Up', 
                         'isr_down':'ISR_Down', 'fsr_up':'FSR_Up','fsr_down':'FSR_Down'}.items():
            tt_bb_dict['weight'][f"{tt}_{sys}_{year}"] = get_weight( # new , old , total_events_old, old_xsec, year
                csv[index[f'TTbb_{p}_powheg_{year}'],col_dict[f'ttbb_{key}']],
                csv[index[f'TTTo{p}_powheg_{year}'], col_dict[f'ttbb_{key}']],
                csv[index[f'TTTo{p}_powheg_{year}'], col_dict[f'{key}']],
                tt, 
                year
            )
        for key in ['hdampUp','hdampDown']:
            tt_bb_dict['weight'][f"{tt}_{key}_{year}"] = get_weight( # new , old , total_events_old, old_xsec, year
                csv[index[f'TTbb_{p}_{key}_{year}'],ded_col_dict[f'tt_bb_yield']],
                csv[index[f'TTTo{p}_{key}_{year}'], ded_col_dict[f'tt_bb_yield']],
                csv[index[f'TTTo{p}_{key}_{year}'], ded_col_dict[f'Tot_Yield']],
                tt, 
                year
            )

        for key in ['UEUp','UEDown','erdOn']:
            tt_bb_dict['scale'][f"{tt}_{key}_{year}"] = get_scale(
               float(csv[index[f'TTTo{p}_powheg_{year}'], col_dict[f'ttbb_Tot_Yield']])/float(csv[index[f'TTTo{p}_powheg_{year}'], col_dict[f'Tot_Yield']]),
               float(csv[index[f'TTTo{p}_{key}_{year}'], ded_col_dict[f'tt_bb_yield']])/float(csv[index[f'TTTo{p}_{key}_{year}'], ded_col_dict[f'Tot_Yield']])
            )

tt_bb_dict.to_pickle('/home/bcaraway/ttZh_ana/DeepSleep/data/tt_bb_nom.pkl')
#for k,v in tt_bb_dict['scale'].items():
#    print(k,v)
# murf, isr, fsr weights


