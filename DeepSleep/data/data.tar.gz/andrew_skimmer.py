#! /usr/bin/env python

#################################################################################################################
###  TTX_debug.py : a script to print out selected events in Bryan Caraway's ttX boosted measurement (TOP-21-003)
#################################################################################################################

import ROOT as R
R.gROOT.SetBatch(True)  ## Don't display histograms or canvases when drawn

import os
import sys
import json
import math
import subprocess
import re
import config.ana_cff as cfg
from lib.fun_library import t2Run

## User-defined constants
MAX_EVT =    -1  ## Maximum number of events to process
PRT_EVT =    -1  ## Print to screen every Nth event
VERBOSE = False  ## Print extra info about each event

## Function to mask events using JSON file
def PassJSON(JSON, run, LS):
    Good_LS = False
    if not str(run) in JSON.keys():
        return Good_LS
    for iLS in range( len( JSON[str(run)] ) ):
        if int(LS) >= JSON[str(run)][iLS][0] and int(LS) <= JSON[str(run)][iLS][-1]:
            Good_LS = True
            break
        if Good_LS: break

    return Good_LS
## End function: PassJSON(self, run, LS)                                                                                                                       

## Main file processing with event selection
@t2Run
def main():

    ###################
    ## Initialize files
    ###################

    ## Location of input files
    in_dir = '/cms/data/store/user/bcaraway/NanoAODv7/PostProcessed/'
    in_file_names = []
    # in_file_names.append(in_dir+'2017/TTToSemiLeptonic_2017/826DC223-5662-214D-AD4C-49E268AE7F55_Skim_83.root')
    in_file_names.append(in_dir+'2017/Data_SingleMuon_2017_PeriodD/9A53E75E-4E0E-5A4A-A8C3-A91333DA906D_Skim_8.root')
    YEAR = re.search(f'201\d', in_file_names[0]).group()

    ## Chain together trees from input files
    ch = R.TChain('Events')

    for in_file_name in in_file_names:
        print( 'Opening file: '+in_file_name)
        ch.Add( in_file_name )

    ## Set "isData" flag for Golden JSON
    isData = ('Data_' in in_file_names[0])

    ## Load Golden JSON file
    if isData and '2017' in in_file_names[0]:
        JSON_FILE = cfg.goodLumis_file[YEAR]
        #JSON_FILE = 'data/good_lumis/Cert_294927-306462_13TeV_UL2017_Collisions17_GoldenJSON.txt'  ## 2017 Golden JSON 
        print( '\nLoading 2017 Golden JSON from %s' % JSON_FILE)
        with open(JSON_FILE) as json_file:
            JSON = json.load(json_file)


    #############
    ## Event loop
    #############

    print( '\nAbout to run over %d events in chain, up to a maximum of %d\n' % (ch.GetEntries(), MAX_EVT))

    nPass = 0  ## Count events passing selection cuts

    for iEvt in range(ch.GetEntries()):

        if iEvt >= MAX_EVT and MAX_EVT > 0: break
        if iEvt % PRT_EVT is 0 and PRT_EVT > 0: print( 'Event #', iEvt)

        ch.GetEntry(iEvt)

        ## Define unique string listing event info
        evt_str = 'Run %d, LS %d, event %d' % (ch.run, ch.luminosityBlock, ch.event)
        if VERBOSE:
            print( evt_str)

        ####################################################
        ## Pre-select events based on simple RECO quantities
        ####################################################

        nMuon = ch.nMuon     ## Number of RECO muons in the event
        nEle  = ch.nElectron ## Number of RECO electrons in the event
        nJet  = ch.nJet      ## Number of RECO AK4 jets (dR = 0.4) in the event
        nFat  = ch.nFatJet   ## Number of RECO AK8 jets (dR = 0.8) in the event

        ## Quickly eliminate events not passing basic multiplicity cuts
        if nMuon + nEle <  1: continue
        if nFat         <  1: continue
        if nJet         <  5: continue
        if ch.MET_pt    < 20: continue


        if ch.event == 212213958 : print("HERE")
        
        ################################
        ## Golden JSON and good vertices
        ################################

        ## Remove data events not in Golden JSON
        if isData:
            pass_JSON = PassJSON(JSON, ch.run, ch.luminosityBlock)
            if not pass_JSON:
                if VERBOSE: print( '%s not in Golden JSON' % evt_str)
                continue

        if ch.event == 212213958 : print("HERE")

        ## Remove events with no good collision vertices
        #if ch.PV_npvsGood < 1:
        #    if VERBOSE: print( '%s has %d good PVs' % (evt_str, ch.PV_npvsGood))
        #    continue

        ##################
        ## Selected lepton
        ##################

        ## Define the selected lepton for the event
        nLeps   = 0
        lepVec  = R.TLorentzVector()
        lepFlav = ''
        lepSign = 0

        ## Loop over muons
        for iMu in range(nMuon):
            if ch.Muon_mediumId        [iMu]  <  1: continue
            if ch.Muon_miniPFRelIso_all[iMu]  >= 0.2: continue
            if ch.Muon_pt              [iMu]  <= 30: continue
            if abs(ch.Muon_eta         [iMu]) >= 2.4: continue
            if abs(ch.Muon_sip3d       [iMu]) >= 4.0: continue
            ## Muon is selected lepton candidate
            nLeps += 1
            lepVec.SetPtEtaPhiM(ch.Muon_pt[iMu], ch.Muon_eta[iMu], ch.Muon_phi[iMu], ch.Muon_mass[iMu])
            lepFlav = 'Mu'
            lepSign = ch.Muon_charge[iMu]
        ## End loop: for iMu in range(nMuon)
        if nLeps > 1: continue
        
        if ch.event == 212213958 : print("HERE")

        ## Loop over electrons
        for iEle in range(nEle):
            if ch.Electron_cutBasedNoIso   [iEle]  <    4: continue
            if ch.Electron_miniPFRelIso_all[iEle]  >= 0.1: continue
            if ch.Electron_pt              [iEle]  <=  30 if YEAR == '2016' else 35: continue
            if abs(ch.Electron_eta         [iEle]) >= 2.5: continue
            if abs(ch.Electron_sip3d       [iEle]) >= 4.0: continue
            ## Electron is selected lepton candidate
            nLeps += 1
            lepVec.SetPtEtaPhiM(ch.Electron_pt[iEle], ch.Electron_eta[iEle], ch.Electron_phi[iEle], ch.Electron_mass[iEle])
            lepFlav = 'Ele'
            lepSign = ch.Electron_charge[iEle]
        ## End loop: for iEle in range(nEle)
        if nLeps != 1: continue
        
        if ch.event == 212213958 : print("HERE")

        ## Make sure there is no additional SFOS lepton forming an invariant mass < 12 GeV with the selected lepton
        passSFOS = True
        ### this is not in my (Bryan's) skimmmer so do not do this
        if lepFlav == 'Mu':
            for xMu in range(nMuon):
                if ch.Muon_charge[xMu] == lepSign: continue
                if ch.Muon_softId[xMu] != 1:       continue
                xVec = R.TLorentzVector()
                xVec.SetPtEtaPhiM(ch.Muon_pt[xMu], ch.Muon_eta[xMu], ch.Muon_phi[xMu], ch.Muon_mass[xMu])
                #if (xVec+lepVec).M() < 12:
                #    passSFOS = False
                #    break
            ## End loop: for xMu in range(nMuon)
        ## End conditional: if lepFlav == 'Mu'
        if lepFlav == 'Ele':
            for xEle in range(nEle):
                if ch.Electron_charge  [xEle] == lepSign: continue
                if ch.Electron_cutBased[xEle]  < 2:       continue
                xVec = R.TLorentzVector()
                xVec.SetPtEtaPhiM(ch.Electron_pt[xEle], ch.Electron_eta[xEle], ch.Electron_phi[xEle], ch.Electron_mass[xEle])
                #if (xVec+lepVec).M() < 12:
                #    passSFOS = False
                #    break
            ## End loop: for xEle in range(nEle)
        ## End conditional: if lepFlav == 'Ele'
        if not passSFOS: continue

        ###################
        ## Selected AK8 jet
        ###################

        ## Only consider events containing at least 1 candidate fat jet
        nGoodFat = 0
        #min_bbvL = 0.7999999999999
        min_bbvL = 0.0
        fatVec   = R.TLorentzVector()
        for iFat in range(nFat):
            if ch.FatJet_jetId    [iFat]  <   2: continue
            if ch.FatJet_pt       [iFat]  < 200: continue
            if ch.FatJet_msoftdrop[iFat]  <  50: continue
            if ch.FatJet_msoftdrop[iFat]  > 200: continue
            if abs(ch.FatJet_eta  [iFat]) > 2.4: continue
            ## Fat jet is potentially selected, pending lepton cleaning
            fatVecTmp = R.TLorentzVector()
            fatVecTmp.SetPtEtaPhiM(ch.FatJet_pt[iFat], ch.FatJet_eta[iFat], ch.FatJet_phi[iFat], ch.FatJet_msoftdrop[iFat])
            if ch.event == 212213958 : 
                print("HERE before lep cleaning")
                print(ch.FatJet_pt[iFat], ch.FatJet_eta[iFat], ch.FatJet_phi[iFat], ch.FatJet_msoftdrop[iFat])
                print(lepVec.Eta(), lepVec.Phi())
                print(fatVecTmp.DeltaR(lepVec))
            if fatVecTmp.DeltaR(lepVec) <= 0.8: continue
            if ch.event == 212213958 : print("HERE after lep cleaning")
            ## Apply double b-tag cut for candidate selection
            #if ch.FatJet_deepTagMD_bbvsLight[iFat] <= min_bbvL: continue
            fatVec = fatVecTmp
            nGoodFat += 1
        ## End loop: for iFat in range(nFat)
        if nGoodFat < 1: continue
        if ch.event == 212213958 : print("HERE")

        ####################
        ## Selected AK4 jets
        ####################

        ## Only consider events containing at least 5 AK4 jets
        nGoodJet = 0
        nBtagOut = 0
        for iJet in range(nJet):
            if ch.Jet_jetId  [iJet]  <   2: continue
            if ch.Jet_puId   [iJet]  <   4 and \
               ch.Jet_pt     [iJet]  <  50: continue
            if ch.Jet_pt     [iJet]  <  30: continue
            if abs(ch.Jet_eta[iJet]) > 2.4: continue
            ## Jet is potentially selected, pending lepton cleaning
            jetVec = R.TLorentzVector()
            jetVec.SetPtEtaPhiM(ch.Jet_pt[iJet], ch.Jet_eta[iJet], ch.Jet_phi[iJet], ch.Jet_mass[iJet])
            if jetVec.DeltaR(lepVec) <= 0.4: continue
            nGoodJet += 1
            #nBtagOut += (ch.Jet_btagDeepB[iJet] >= 0.4941 and jetVec.DeltaR(fatVec) >= 0.8)
            nBtagOut += int(ch.Jet_btagDeepB[iJet] >= cfg.ZHbb_btagWP[YEAR])
        ## End loop: for iJet in range(nJet)
        if nGoodJet < 5: continue
        if nBtagOut < 2: continue

        if ch.event == 212213958 : print("HERE")

        ##########################
        ## Trigger and MET filters
        ##########################

        ## Trigger for muon and electron events
        #if lepFlav == 'Mu':
        #    if not (ch.HLT_IsoMu27 or ch.HLT_Mu50 or ch.HLT_OldMu100 or ch.HLT_TkMu100): continue
        #if lepFlav == 'Ele':
        #    if not (ch.HLT_Ele32_WPTight_Gsf_L1DoubleEG or ch.HLT_Ele35_WPTight_Gsf or ch.HLT_Photon200 or
        #            ch.HLT_Ele115_CaloIdVT_GsfTrkIdT or ch.HLT_Ele50_CaloIdVT_GsfTrkIdT_PFJet165): continue

        ## MET filters
        if not (ch.Flag_goodVertices and ch.Flag_globalSuperTightHalo2016Filter and
                ch.Flag_HBHENoiseFilter and ch.Flag_HBHENoiseIsoFilter and
                ch.Flag_EcalDeadCellTriggerPrimitiveFilter and ch.Flag_BadPFMuonFilter): continue
        if isData and not ch.Flag_eeBadScFilter: continue
        #if not ch.Flag_ecalBadCalibFilterV2: continue
        # need to year-proof this conditional
        if YEAR != "2016" and not (ch.Flag_ecalBadCalibFilterV2): continue
        if ch.event == 212213958 : print("HERE")

        ## Event selected!
        nPass += 1
        print( evt_str)

    ## End loop over events in chain (iEvt)

    print( '\n\n%d events processed, %d selected' % (iEvt+1, nPass))

## Define 'main' function as primary executable
if __name__ == '__main__':
    main()
